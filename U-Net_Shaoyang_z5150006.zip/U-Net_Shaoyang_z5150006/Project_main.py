## Import
from UNet import *
import os
import glob
import cv2
import numpy as np
import pandas as pd
import skimage.io as io
import skimage.transform as trans
import matplotlib.pyplot as plt

from skimage.transform import resize
from keras.preprocessing.image import ImageDataGenerator
from keras.preprocessing import image
from skimage import img_as_ubyte

def get_data(image_path, label_path):
    #seed = np.random.seed(10)
    X_train = []
    Y_train = []

    images = glob.glob(image_path + "/*.jpg")
    images.sort()
    for myImg in images:
        image = cv2.imread(myImg)
        image = cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
        image = np.array(image, dtype = 'float32') / 255.0
        X_train.append(image)

    #Y_label = np.zeros((512, 512, 1), dtype=np.bool)
    labels = glob.glob(label_path + "/*.jpg")
    labels.sort()
    for myLabel in labels:
        label = cv2.imread(myLabel)
        label = cv2.cvtColor(label,cv2.COLOR_BGR2GRAY)
        label = np.array(label, dtype = 'float32') / 255.0
        Y_train.append(label)

    X_train = np.array(X_train)
    Y_train = np.array(Y_train)

    Y_train[Y_train > 0.5] = 1 #white
    Y_train[Y_train < 0.5] = 0 #black

    X_train = X_train.reshape((-1,512,512,1))
    Y_train = Y_train.reshape((-1,512,512,1))

    return X_train, Y_train

## test and save

def Test_Generator(path):
    for i in range(30):# The number of Test Image is 30
        if i < 10:
            image = io.imread(os.path.join(path, 'train-volume0%d.jpg'%i), as_gray = True)
        else:
            image = io.imread(os.path.join(path, 'train-volume%d.jpg'%i), as_gray = True)

        image = image / 255.0
        #image = trans.resize(image, (512,512)) # Resize image
        image = np.reshape(image,image.shape+(1,))
        image = np.reshape(image,(1,)+image.shape) # Extending as same dimention as input of traing which is [2,512,512]

        yield image


def saveResult(path, npyfile, num_class = 2):
    for i, item in enumerate(npyfile):
        image = item[:,:,0]
        #image = trans.resize(image, (512,512))
        io.imsave(os.path.join(path,"%d_predict.jpg"%i),img_as_ubyte(image))

# main
image_path = 'data/Train_data/Train_img'
label_path = 'data/Train_data/Train_label'
test_path = 'data/Test_data/Test_img'


train_image, train_label = get_data(image_path, label_path)

model = unet()
model_checkpoint = ModelCheckpoint('unet_membrane.hdf5', monitor = 'val_acc', verbose = 1, save_best_only = True)
# Recall function, monitor is the check value which to check Loss and make it as small as possiable
# save_best_only is to make sure to save the best model on test data

history = model.fit(train_image,
                    train_label,
                    batch_size = 2,
                    validation_split = 0.01,
                    epochs = 30, # different epoch setting as 10, 15, 30, 50
                    callbacks = [model_checkpoint])

test_generator = Test_Generator(test_path)
results = model.predict_generator(test_generator, 30, verbose = 1) # Steps = 30
saveResult('data/result', results)
